import React from "react";
import { View,Button,Text } from "react-native";
import { useDispatch } from "react-redux";
import { addItem } from "./actions";

const ProductList = ({products}) =>{
    const dispatch = useDispatch();
    return(
        <View>
            {products.map(p => (
                <View key={p.id}>
                    <Text>{p.name}</Text>
                    <Button title="Add to Cart" onPress={()=>dispatch(addItem(p))}/>
                </View>
            ))}
        </View>
    );
};
export default ProductList;