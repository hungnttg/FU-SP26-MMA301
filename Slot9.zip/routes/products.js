const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
//hien thi danh sach san pham
router.get('/admin',async (req,res)=>{
    try {
        const products = await Product.find();
        res.render('admin',{products,product:null});
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//them san pham
router.post('/add-product',async (req,res)=>{
    const {id,name,price,description}=req.body;//laydu lieu nguoi dung nhap
    const newProduct = new Product({id,name,price,description});
    try {
        await newProduct.save();//luu du lieu
        res.redirect('/admin');//tro ve trang admin
    } catch (error) {
        res.status(500).send(error);
    }
});
//lay thong tin san pham can sua va hien thi trong form
router.get('/edit-product/:id', async (req,res)=>{
    try {
        //lay va san pham theo id
        const product = await Product.findById(req.params.id);
        const products = await Product.find();//lay danh sach
        res.render('admin',{product,products});//gui danh sach san pham moi ve admin
    } catch (error) {
       res.status(500).send(error); 
    }
});
//sua san pham
router.post('/edit-product/:id',async (req,res)=>{
    const {name,price,description}=req.body;//lay du lieu nguoi dung nhap
    try {
        //thuc hien update
        await Product.findByIdAndUpdate(req.params.id,{name,price,description});
        //tra ve trang adin
        res.redirect('/admin');
    } catch (error) {
        res.status(500).send(error);
    }
});
//xoa san pham
router.post('/delete-product/:id',async (req,res)=>{
    try {
        await Product.findByIdAndDelete(req.params.id);//thuc hien xoa
        res.redirect('/admin');//load lai trang admin
    } catch (error) {
        res.status(500).send(error);
    }
});
module.exports=router;