import { View } from "react-native";
import Slot_2_3_Con from "./Slot2_3_Con";
export default function Slot2_3_Cha(){
    const userName = "Nguyen Van A";
    return(
        <View>
            {/* truyen name tu cha sang con */}
            <Slot_2_3_Con name={userName}/>
        </View>
    );
}