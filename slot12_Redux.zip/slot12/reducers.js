//dinh nghia cac ham khai bao trong actions
import { createReducer } from "@reduxjs/toolkit";
import { addItem,removeItem } from "./actions";
const initialState = {items: []};
const cartReducer = createReducer(initialState,builder =>{
    builder
    //dinh nghia ham addItem
        .addCase(addItem,(state,action)=>{
            //kiem tra xem co ton tai san pham khong?
            const existingItemIndex = state.items.findIndex(item=>item.id === action.payload.id);
            //neu ton tai
            if(existingItemIndex !== -1){
                //so luong tang them 1
                state.items[existingItemIndex].quantity++;
            }
            else {//neu chua ton tai san pham
                //tao moi voi so luong la 1
                state.items.push({...action.payload,quantity:1});

            }
        })
        //dinh nghia ham removeItem
        .addCase(removeItem,(state,action)=>{
            //co ton tai san pham khong
            //kiem tra xem co ton tai san pham khong?
            const existingItemIndex = state.items.findIndex(item=>item.id === action.payload.id);
            //neu ton tai thi so luong tru di 1
            if(existingItemIndex !== -1){
                state.items[existingItemIndex].quantity--;
                //kiem tra neu so luong = 0 thi se xoa san pham khoi gio hang
                if(state.items[existingItemIndex].quantity === 0){
                    state.items.splice(existingItemIndex,1);
                }
            }
        });
});
export default cartReducer;