//npm i @react-navigation/stack
//npm i @react-navigation/native
import React,{useState,useEffect} from "react";
import Product from "./Product";
import { useNavigation,useRoute } from "@react-navigation/native";
import { FlatList } from "react-native";
const ListProductFn = () =>{
    //dieu huong va mang du lieu theo
    const navigation = useNavigation();
    const route = useRoute();
    //code
    const [prd,setPrd]=useState(null);
    //ham ket xuat du lieu
    const renderItemFL = ({item})=>{
        return(
            //hien thi product
            //khi nguoi dung click item thi se hien thi chi tiet san pham
            <Product dataProd={item} handlePress={()=>viewDetail({p: item})}/>
        );
    };
    //dinh nghia ham viewdetail
    const viewDetail = ({p}) =>{
        navigation.navigate('DetailFn',{data:p});//hien thi chi tiet san pham
    };
    //ham doc du lieu
    const getProducts = async () =>{
        const url='https://hungnttg.github.io/shopgiay.json';//duong dan
        const response = await fetch(url,{method:'GET'});//doc du lieu
        const resJson = await response.json();//chuyen sang json
        //cap nhat vao state prd
        setPrd(resJson.products);
    };
    //load du lieu khi khoi tao
    useEffect(()=>{
        getProducts();
    },[]);
    //giao dien
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFL}
            numColumns={2}
            removeClippedSubviews
        />
    );
}
export default ListProductFn;