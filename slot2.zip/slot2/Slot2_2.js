import { useState } from "react";
import { Button, Text, View } from "react-native";
export default function Counter(){
    // khai bao bien
    const [count,setCount]=useState(0);//khoi tao gia tri khi chua click
    //giao dien
    return(
        <View>
            <Text>
                So lan click: {count}
            </Text>
            <Button title="Click me" onPress={()=>setCount(count+1)} />
        </View>
    );
}