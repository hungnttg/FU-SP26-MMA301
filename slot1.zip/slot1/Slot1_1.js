//1. Import thu vien
import React from "react";
import { Text, View } from "react-native";
//2. Dinh nghia class
class Slot1_1 extends React.Component{
    render(){
        return(
            <View>
                <Text>Day la ung dung React Native Class</Text>
            </View>
        );
    }
}
//3. Export
export default Slot1_1;