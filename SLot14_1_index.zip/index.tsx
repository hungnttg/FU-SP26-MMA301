import { Image } from 'expo-image';
import { Platform, StyleSheet } from 'react-native';

import { HelloWave } from '@/components/hello-wave';
import ParallaxScrollView from '@/components/parallax-scroll-view';
import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Link } from 'expo-router';
import Slot4_1 from '../slot4_1/SLot4_1'
import Config from '../slot5_1/Config';
import Slot10 from '../slot10_1/Slot10'
import Slot11 from '../slot11_1/Slot11';
import Slot12 from '../slot12/Slot12'
import App12 from '../slot12_1/App12';
import Left from '../slot14/Left';
//bottom navigation
//npm i @react-navigation/native
//npm i @react-navigation/bottom-tabs
//npm i react-native-screen
//npm i react-native-safe-area-context
//npm i @expo/vector-icons
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {Ionicons} from '@expo/vector-icons';
import { Text,View } from 'react-native';

const Tab = createBottomTabNavigator();//tao tab


function HomeScreen() {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Home</Text>
      <Left/>
    </View>
  );
}
function SettingsScreen(){
  return(
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Settings</Text>
    </View>
  );
}
function ViDu(){
  return(
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>ViDu</Text>
    </View>
  );
}
export default function App(){
  return(
    <Tab.Navigator>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({color,size}) =>(
            <Ionicons name="home" size={size} color={color}/>
          )
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          tabBarIcon: ({color,size})=>(
            <Ionicons name="settings" size={size} color={color}/>
          )
        }}
      />
      <Tab.Screen
        name="ViDu"
        component={ViDu}
        options={{
          tabBarIcon: ({color,size})=>(
            <Ionicons name="airplane" size={size} color={color}/>
          )
        }}
      />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 178,
    width: 290,
    bottom: 0,
    left: 0,
    position: 'absolute',
  },
});
