//npm i axios
import React,{useState} from "react";
import { View,Text,TextInput,Button,StyleSheet } from "react-native";
import {loginUser} from './api';//ham dang nhap
const LoginScreen = ({navigation}) =>{
    const [username,setUsername]=useState('');
    const [password,setPassword]=useState('');
    const [message,setMessage]=useState('');
    const [error,setError]=useState('');
    const handleLogin = async () =>{
        try {
            const response = await loginUser(username,password);
            if(response.role){
                //navigation.navigate('Home',{role: response.role});
                setMessage("Dang nhap thanh cong");
                console.log(response);
            }
        } catch (error) {
            setError(error.message);//thong bao loi
            console.error('Login failed: ',error);
        }
    };
    return(
        <View style={{flex:1}}>
            <Text>Username: </Text>
            <TextInput
                style={{borderWidth:1,}}
                value={username}
                onChangeText={setUsername}
                placeholder="Enter username"
            />
            <Text>Password: </Text>
            <TextInput
                style={{borderWidth:1,}}
                value={password}
                onChangeText={setPassword}
                placeholder="Enter Password"
                secureTextEntry
            />
            {error ? <Text style={{color:'red'}}>{error}</Text> :
            <Text>{message}</Text>}
            <Button title="Login" onPress={handleLogin} />
        </View>
    );
};
export default LoginScreen;