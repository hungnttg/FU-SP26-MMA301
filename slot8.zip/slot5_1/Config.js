import DetailFn from "./DetailFn";
import ListProductFn from "./ListProductFn";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import CartFn from './CartFn';
const Stack = createStackNavigator();
const Config = ()=>{
    return(
        
            <Stack.Navigator initialRouteName="ListProductFn">
                {/* dinh nghia cac man hinh se duoc goi */}
                <Stack.Screen name="ListProductFn" component={ListProductFn}/>
                <Stack.Screen name="DetailFn" component={DetailFn}/>
                <Stack.Screen name="CartFn" component={CartFn}/>
            </Stack.Navigator>
        
    );
}
export default Config;