import React from "react";
import { View,Text,Image,StyleSheet,TouchableWithoutFeedback } from "react-native";
const Product = ({dataProd,handlePress}) =>{
    //du lieu
    //const {dataProd = {}} = props;
    //dinh nghia ham xu ly su kien
    const fun_handlePress = () =>{
        //neu co su kien xay ra
        if(handlePress){ 
            // gui du lieu cho su kien
            handlePress(dataProd);
        }
    };
    //layout
    return(
        <View style={styles.container}>
            <TouchableWithoutFeedback onPress={fun_handlePress}>
                <View>
                    <Image source={{uri:dataProd.search_image}} style={styles.image}/>
                    <Text>{dataProd.styleid}</Text>
                    <Text>{dataProd.brands_filter_facet}</Text>
                    <Text>{dataProd.price}</Text>
                    <Text>{dataProd.product_additional_info}</Text>
                </View>
            </TouchableWithoutFeedback>
        </View>
    );
}
export default Product;
const styles = StyleSheet.create({
    container:{flex:1},
    image:{width:200,height:200,borderWidth:1}
});