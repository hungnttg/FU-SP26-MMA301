//dem so lan click
//class
import React from "react";
import { Text, View } from "react-native";
export default class Slot2_1 extends React.Component{
    //ham khoi tao
    constructor(props){
        super(props);
        this.state={
            //khai bao bien
            text: "Click me",
            dem: 0,
        };
    }
    //dinh nghia ham
    updateText(){
        this.setState((preState)=>{
            return {
                dem: preState.dem +1,
                text: 'Ban vua click lan ',
            }
        });
    }
    render(){
        return(
            <View>
                {/* goi ham */}
                <Text onPress={()=>this.updateText()}>      
                    {/* goi bien */}
                    {this.state.text} : {this.state.dem}
                </Text>
            </View>
        );
    }
}