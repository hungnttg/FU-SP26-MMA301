import React from "react";
import { ScrollView,Button } from "react-native";
import Product from "./Product";
const DetailFn = ({navigation,route})=>{
    //code
    //lay du lieu truyen
    const data1 = route.params?.data || "";
    //viet ham truyen du lieu sang gio hang
    const addToCart = ({d})=>{
        navigation.navigate('CartFn',{data: d});
    };
    //layout
    return(
        <ScrollView>
            <Product dataProd={data1}/>
            <Button title="Add to cart" onPress={()=>addToCart({d:data1})}/>
        </ScrollView>
    );
}
export default DetailFn;