import React from "react";
import { View,FlatList } from "react-native";
import Product from "./Product";
export default class ListProduct extends React.Component{
    //ham khoi tao
    constructor(props){
        super(props);
        this.state={products: null,};//khai bao state ban dau
        //khai bao cac ham can dung
        this.getProducts = this.getProducts.bind(this);//ham doc du lieu tu APi
        this.renderItem = this.renderItem.bind(this);
    }
    //ham load du lieu
    componentDidMount(){
        this.getProducts();
    }
    //dinh nghia cac ham
    //ham lay du lieu
    async getProducts(){
        const url='https://hungnttg.github.io/shopgiay.json';
        let response = await fetch(url,{method:'GET'});//tien hanh doc
        let responseJSON = await response.json();//chuyen du lieu sang json
        //cap nhat vao state
        this.setState({
            products: responseJSON.products,
        });
    }
    //render view
    renderItem({item}){
        return(
            <Product dataProd={item}/>
        );
    }
    //view
    render(){
        return(
            
                <FlatList
                    data={this.state.products}
                    renderItem={this.renderItem}
                    numColumns={3}
                    removeClippedSubviews
                />
           
        );
    };
    
}