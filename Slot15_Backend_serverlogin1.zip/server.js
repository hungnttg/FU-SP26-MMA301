const express  =require('express');
const mongoose = require('mongoose');
const userRoutes  = require('./routes/users');
//npm i cors
//npm i body-parser
const cors = require('cors');
const bodyParder = require('body-parser');
//
const app = express();
//
mongoose.connect('mongodb://localhost:27017/a1',{

})
.then(()=>console.log('Connected'))
.catch(err=>console.log(err));
//
app.use(cors());
app.use(bodyParder.json());
//
app.use('/api/users',userRoutes);
//
app.listen(3001,()=>{
    console.log('server dang chay o cong 3001');
});