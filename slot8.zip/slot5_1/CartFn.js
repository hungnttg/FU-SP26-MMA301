import React,{useState} from "react";
import { View,ScrollView,Text,FlatList,Button } from "react-native";
import Product from './Product';
global.mycart=[];//luu gio hang
const CartFn = ({route}) =>{
    //code
    const [count,setCount]=useState(1);//luu so luong
    const [list,setList]=useState(global.mycart);//luu cac san pham trong gio hang
    const data = route.params?.data || "";//lay du lieu tu Detail
    //lay toan bo san pham trong gio hang
    const getAllProductInCart = () =>{
        const newList = [{data},...global.mycart];//them san pham vao gio hang
        global.mycart = newList;//cap nhat gio hang moi vao bien toan cuc
        setList([...newList]);//cap nhat lai state
    };
    //xuat du lieu trong gio hang
    const remderCartItem = ({index,item}) =>{
        return(
            <Product dataProd={global.mycart[index].data}/>
        );
    };
    //layout
    return(
        <View>
            <ScrollView>
                <Product dataProd={data} />
                <Button title="+" onPress={()=>setCount(count+1)}/>
                 <Text>So luong san pham: {count}</Text>   
                <Button title="-"onPress={()=>setCount(count-1)}/>
                <Button title="All Product In Cart" onPress={getAllProductInCart}/>
                <FlatList
                    data={list}
                    renderItem={remderCartItem}
                    numColumns={2}
                    removeClippedSubviews
                />
            </ScrollView>
        </View>
    );
}
export default CartFn;