//1. Import thu vien
import { Text, View } from "react-native";
//2. dinh nghia ham
const Slot1_2 = () =>{
    return(
        <View>
            <Text>Day la ung dung React Native Function</Text>
        </View>
    );
}
//3. Export ham
export default Slot1_2;