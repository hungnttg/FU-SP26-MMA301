import DetailFn from "./DetailFn";
import ListProductFn from "./ListProductFn";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
//file config de goi cac file khac
const Stack = createStackNavigator();
const Nav6 = () =>{
    return(
        
            <Stack.Navigator initialRouteName="ListProductFn">
                {/* ten cac man hinh se goi */}
                <Stack.Screen name="ListProductFn" component={ListProductFn}/>
                <Stack.Screen name="DetailFn" component={DetailFn}/>
            </Stack.Navigator>
        
    );
}
export default Nav6;