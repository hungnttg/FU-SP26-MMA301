// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
//import { getAnalytics } from "firebase/analytics";
import {getStorage} from 'firebase/storage';
import {getAuth} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCqPUJz-_KnPW-tkEPvw3xgxynMHkVjIjU",
  authDomain: "sp26mma.firebaseapp.com",
  projectId: "sp26mma",
  storageBucket: "sp26mma.firebasestorage.app",
  messagingSenderId: "974061708974",
  appId: "1:974061708974:web:57bd7e74012c249328ef3f1",
  measurementId: "G-Y4Y5V0M5WC1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
//const analytics = getAnalytics(app);
//export cac bien de su dung sau nay
export const FIRESTORE_DB=getFirestore(app);
export const FIREBASE_AUTH = getAuth(app);
//cai mot so thu vien
//npx expo install expo-dev-client
//npx expo install @react-native-firebase/app