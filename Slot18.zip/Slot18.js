//npm i react-native-maps
import React,{useState} from "react";
import {View,Text,StyleSheet} from 'react-native';
import MapView, {Marker} from 'react-native-maps';
const Slot18 = () => {
    //vi tri can hien thi tren ban do
    const [coordinate,setCoordinate] = useState({
        latitude: 21.0278,
        longitude: 105.8342
    });
    //su kien ban do
    const handleMapPress = (e) =>{
        //set vi tri hien thoi 
        const {latitude,longitude} = e.nativeEvent.coordinate;
        setCoordinate({latitude,longitude});//cap nhat vi tri
    };
    //gia dien
    return(
        <View style={styles.container}>
            <MapView style={styles.map}
                initialRegion={{
                    latitude: coordinate.latitude,
                    longitude: coordinate.longitude,
                    latitudeDelta: 0.01,
                    longitudeDelta: 0.01
                }}
                onPress={handleMapPress}
            >
                <Marker coordinate={coordinate} title="Vi tri da chon" />
            </MapView>
            {/* truong thong tin */}
            <View style={styles.infoBox}>
                <Text style={styles.text}>Vi do: {coordinate.latitude.toFixed(6)}</Text>
                <Text style={styles.text}>Kinh do: {coordinate.longitude.toFixed(6)}</Text>
            </View>
        </View>
    );

}
const styles = StyleSheet.create({
    container:{
        flex:1,
    },
    map:{
        flex:1,
    },
    infoBox: {
        padding:10,
        backgroundColor:'white',
        alignItems:'center',
    },
    text:{
        fontSize:18,
        fontWeight:'bold',
    },
});
export default Slot18;