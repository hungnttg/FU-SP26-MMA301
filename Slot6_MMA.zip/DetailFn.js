import React from "react";
import { ScrollView,Button } from "react-native";
import Product from "./Product";
const DetailFn = ({navigation,route}) => {
    //code
    const data1 = route.params?.data || ""; //lay du lieu tu listproduct chuyen sang
    const addToCart = ({d}) =>{//them vao gio hang
        navigation.navigate('CartFn',{data:d});//truyen du lieu sang gio hang
    };
    //layout
    return(
        <ScrollView>
            <Product dataProd={data1}/>
            <Button title="Add to cart" onPress={()=>addToCart({d: data1})}/>
        </ScrollView>
    );
}
export default DetailFn;