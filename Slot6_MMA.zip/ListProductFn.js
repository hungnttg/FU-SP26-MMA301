import React,{useState,useEffect} from "react";
import { FlatList } from "react-native";
import Product from "./Product";
import { useNavigation,useRoute } from "@react-navigation/native";
const ListProductFn = () =>{
    //dieu huong
    const navigation =useNavigation();
    const route = useRoute();
    //khai bao bien
    const [prd,setPrd]=useState(null);
    //ham ket xuat du lieu
    const renderItemFlatList = ({item}) =>{
        return(
            <Product dataProd={item} handlePress={()=>viewDetail({p:item})}/>
        );
    };
    //viet ham viewDetail
    const viewDetail = ({p}) =>{
        navigation.navigate('DetailFn',{data:p});//dieu huong sang trang detail
    };
    //ham doc du lieu tu API
    const getProducts = async () =>{
        const url = 'https://hungnttg.github.io/shopgiay.json';//duong dan
        const response = await fetch(url,{method:'GET'});//doc du lieu
        const responseJSON = await response.json();//chuyen sang json
        //cap nhat vao trang thai
        setPrd(responseJSON.products);

    };
    //load du lieu
    useEffect(()=>{
        getProducts();//goi ham load du lieu
    },[]);
    //layout
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFlatList}
            numColumns={3}
            removeClippedSubviews
        />
    );
}
export default ListProductFn;