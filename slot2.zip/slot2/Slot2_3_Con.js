import { Text, View } from "react-native";
export default function Slot_2_3_Con({name}){
    return(
        <View>
            <Text>Xin chao {name}</Text>
        </View>
    );
}